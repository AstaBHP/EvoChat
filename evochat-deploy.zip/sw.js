/* EvoChat — Service Worker: تخزين مؤقت ذكي + آلية تحديث فوري */
'use strict';
const CACHE = 'evochat-v9';
const CORE = ['index.html', 'manifest.json', 'icon.svg', 'icon-180.png', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

/* أمر SKIP_WAITING من التطبيق: تفعيل التحديث فورًا */
self.addEventListener('message', (e) => {
  if (e.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // WebSocket لا يُعالج هنا
  if (url.protocol === 'ws:' || url.protocol === 'wss:') return;

  /* الصفحة نفسها: شبكة أولًا دائمًا — الضمان أن التحديثات تصل فورًا
     والكاش احتياط فقط للأوفلاين. هذا يمنع ظهور نسخ قديمة/فارغة نهائيًا. */
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
    e.respondWith(
      fetch(req).then(res => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(req, copy));
        }
        return res;
      }).catch(() => caches.match(req).then(c => c || caches.match('index.html')))
    );
    return;
  }

  // باقي الأصول: Cache-first ثم شبكة (سرعة فورية + تحديث بالخلفية)
  e.respondWith(
    caches.match(req).then(cached => {
      const fetchPromise = fetch(req).then(res => {
        if (res && res.ok && url.origin === location.origin) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(req, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
